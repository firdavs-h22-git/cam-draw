package uz.rasmkochir.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlin.math.atan2
import kotlin.math.hypot

class MainActivity : ComponentActivity() {

    private lateinit var root: FrameLayout
    private lateinit var previewView: PreviewView
    private lateinit var overlay: ImageView
    private lateinit var controls: View
    private lateinit var opacityLabel: TextView
    private lateinit var opacitySeek: SeekBar

    private var hasImage = false
    private var cleanMode = false

    // Barmoq bilan boshqarish holati
    private var lastMidX = 0f
    private var lastMidY = 0f
    private var startDist = 1f
    private var startAngle = 0f
    private var startScale = 1f
    private var startRotation = 0f
    private var activePointers = 0

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCamera()
            else Toast.makeText(this, R.string.camera_denied, Toast.LENGTH_LONG).show()
        }

    private val pickImageLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) loadImage(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)

        root = findViewById(R.id.root)
        previewView = findViewById(R.id.previewView)
        overlay = findViewById(R.id.overlay)
        controls = findViewById(R.id.controls)
        opacityLabel = findViewById(R.id.opacityLabel)
        opacitySeek = findViewById(R.id.opacitySeek)

        updateOpacity(opacitySeek.progress)
        opacitySeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                updateOpacity(progress)
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        findViewById<Button>(R.id.btnPick).setOnClickListener {
            pickImageLauncher.launch("image/*")
        }
        findViewById<Button>(R.id.btnReset).setOnClickListener { resetTransform() }
        findViewById<Button>(R.id.btnClean).setOnClickListener {
            if (!hasImage) {
                Toast.makeText(this, R.string.pick_first, Toast.LENGTH_SHORT).show()
            } else {
                setCleanMode(true)
                Toast.makeText(this, R.string.clean_hint, Toast.LENGTH_LONG).show()
            }
        }

        setupGestures()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) {
            startCamera()
        } else {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun updateOpacity(progress: Int) {
        overlay.alpha = progress / 100f
        opacityLabel.text = getString(R.string.opacity, progress)
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            try {
                val provider = providerFuture.get()
                val preview = Preview.Builder().build().also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }
                provider.unbindAll()
                provider.bindToLifecycle(
                    this,
                    CameraSelector.DEFAULT_BACK_CAMERA,
                    preview
                )
            } catch (e: Exception) {
                Toast.makeText(this, R.string.camera_error, Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun loadImage(uri: Uri) {
        try {
            val maxSide = 2048
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, bounds)
            }
            var sample = 1
            while (bounds.outWidth / sample > maxSide || bounds.outHeight / sample > maxSide) {
                sample *= 2
            }
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp: Bitmap? = contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            }
            if (bmp == null) {
                Toast.makeText(this, R.string.image_error, Toast.LENGTH_SHORT).show()
                return
            }
            overlay.setImageBitmap(bmp)
            overlay.visibility = View.VISIBLE
            hasImage = true
            resetTransform()
        } catch (e: Exception) {
            Toast.makeText(this, R.string.image_error, Toast.LENGTH_SHORT).show()
        }
    }

    private fun resetTransform() {
        overlay.translationX = 0f
        overlay.translationY = 0f
        overlay.scaleX = 1f
        overlay.scaleY = 1f
        overlay.rotation = 0f
    }

    private fun setCleanMode(enabled: Boolean) {
        cleanMode = enabled
        controls.visibility = if (enabled) View.GONE else View.VISIBLE
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        if (enabled) {
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            controller.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    private fun setupGestures() {
        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onLongPress(e: MotionEvent) {
                if (cleanMode) setCleanMode(false)
            }
        })

        root.setOnTouchListener { _, e ->
            detector.onTouchEvent(e)
            if (!hasImage) return@setOnTouchListener false

            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN,
                MotionEvent.ACTION_POINTER_DOWN -> resetBaseline(e, -1)

                MotionEvent.ACTION_POINTER_UP -> resetBaseline(e, e.actionIndex)

                MotionEvent.ACTION_MOVE -> handleMove(e)

                MotionEvent.ACTION_UP,
                MotionEvent.ACTION_CANCEL -> activePointers = 0
            }
            true
        }
    }

    /** Barmoqlar soni oʻzgarganda boshlangʻich qiymatlarni qayta oʻrnatadi. */
    private fun resetBaseline(e: MotionEvent, skipIndex: Int) {
        val idx = (0 until e.pointerCount).filter { it != skipIndex }
        activePointers = idx.size
        if (idx.isEmpty()) return

        if (idx.size >= 2) {
            val a = idx[0]
            val b = idx[1]
            val dx = e.getX(b) - e.getX(a)
            val dy = e.getY(b) - e.getY(a)
            startDist = hypot(dx, dy).coerceAtLeast(1f)
            startAngle = Math.toDegrees(atan2(dy, dx).toDouble()).toFloat()
            startScale = overlay.scaleX
            startRotation = overlay.rotation
            lastMidX = (e.getX(a) + e.getX(b)) / 2f
            lastMidY = (e.getY(a) + e.getY(b)) / 2f
        } else {
            lastMidX = e.getX(idx[0])
            lastMidY = e.getY(idx[0])
        }
    }

    private fun handleMove(e: MotionEvent) {
        if (activePointers == 0) return

        if (e.pointerCount >= 2 && activePointers >= 2) {
            val dx = e.getX(1) - e.getX(0)
            val dy = e.getY(1) - e.getY(0)
            val dist = hypot(dx, dy).coerceAtLeast(1f)
            val angle = Math.toDegrees(atan2(dy, dx).toDouble()).toFloat()

            val newScale = (startScale * dist / startDist).coerceIn(0.1f, 10f)
            overlay.scaleX = newScale
            overlay.scaleY = newScale
            overlay.rotation = startRotation + (angle - startAngle)

            val midX = (e.getX(0) + e.getX(1)) / 2f
            val midY = (e.getY(0) + e.getY(1)) / 2f
            overlay.translationX += midX - lastMidX
            overlay.translationY += midY - lastMidY
            lastMidX = midX
            lastMidY = midY
        } else if (e.pointerCount == 1) {
            val x = e.getX(0)
            val y = e.getY(0)
            overlay.translationX += x - lastMidX
            overlay.translationY += y - lastMidY
            lastMidX = x
            lastMidY = y
        }
    }
}
